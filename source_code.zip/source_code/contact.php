<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8"> 
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <i> <p style = "text-align:center;"> <font size="9" color="Indigo"> Sentiment Analysis for Mobile Phones</font></p></i>
    <style>
            img {
            display: block;
            margin-left: auto;
            margin-right: auto;
            }
            ul {
                list-style-type: none;
                margin: 0;
                padding: 0;
                overflow: hidden;
                background-color: #333;
            }
            li {
                float: left;
            }
            li a {
                display: block;
                color: white;
                text-align: center;
                padding: 14px 16px;
                text-decoration: none;
            }
            li a:hover {
                background-color: #111;
            }
            .button {
                background-color: #4CAF50;
                border: none;
                color: white;
                padding: 15px 32px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-size: 16px;
                margin: 4px 2px;
                cursor: pointer;
            }
            div.b {
            font-size: large;
            }
            div.c {
            font-size: 150%;
            }
        </style>
    </head>
    <body>
        <ul>
            <li> <a class = "active" href = "loginSA.php"> Home </a> </li>
            <li> <a href = "AboutUs.php"> About Us </a> </li>
            <li> <a href = "registerSA.php"> Register </a> </li>
        </ul>
        <h1 style = "text-align:center;">Contact</h1>
        
        <div class="b">Lakshmi Shri Shivaram Ponallaghi<br>lakshiva@iu.edu<br>317-531-0347</div><br>
        <div class="b">Keerthana Yadavelli<br>kyadavel@iu.edu<br>801-330-6969</div><br>
        <div class="b">Sindhuja Madishetty<br>smadishe@iu.edu<br>317-749-7809</div><br>
<html>
    <body>
        <ul>
            <li> <a href = "#Sentiment Analysis"> Sentiment Analysis </a> </li>
            <li> <a href = "logoutSA.php"> Logout </a> </li>
        </ul>
    </body>
</html>